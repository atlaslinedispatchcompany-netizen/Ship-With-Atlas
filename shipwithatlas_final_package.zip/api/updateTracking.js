// placeholder api
module.exports = (req,res)=>{res.end('ok');}