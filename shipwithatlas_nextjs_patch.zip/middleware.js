import { NextResponse } from "next/server";

export function middleware(req) {
  const url = req.nextUrl.clone();
  const hostname = req.headers.get("host");
  if (hostname !== "shipwithatlas.online") {
    url.hostname = "shipwithatlas.online";
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = { matcher: ["/((?!_next|api|static|public).*)"], };
