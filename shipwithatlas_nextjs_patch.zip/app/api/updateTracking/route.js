// Serverless API for tracking updates
