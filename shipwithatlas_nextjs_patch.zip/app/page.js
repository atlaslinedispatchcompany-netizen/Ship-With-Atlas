// Homepage with fade slider and overlay text
